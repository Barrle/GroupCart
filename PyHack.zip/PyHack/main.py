import os, io, re, asyncio, datetime, discord, aiohttp
from discord import app_commands
from discord.ext import tasks
from google import genai
from google.genai import types

g = genai.Client(api_key="AQ.Ab8RN6Lgulsl59PnEeHz_T-7tCI9fHjLnUgSvADK1U79T3RmRg")
P = '''Correct the spelling of this shopping item. Reply with ONLY the corrected singular lowercase product name. If it is not a real product or you cannot tell what it is, reply with ONLY ?
"notebool" -> notebook
"pencik" -> pencil
"pens" -> pen
"pen" -> pen
"asdkjh" -> ?
"pefomeofef" -> ?
"%s" ->'''
cfg = types.GenerateContentConfig(temperature=0, max_output_tokens=60)
API = "http://localhost:8000"
intents = discord.Intents.default()
intents.members = True
client = discord.Client(intents=intents)
http = None

async def call(method, path, body=None, params=None):
    async with http.request(method, API + path, json=body, params=params) as r:
        return await r.json()

class Tree(app_commands.CommandTree):
    async def interaction_check(self, i):
        try:
            await call("POST", "/login", {"name": i.user.display_name, "uid": str(i.user.id)})
        except Exception as e:
            print("link fail", repr(e))
        return True

tree = Tree(client)

async def suggest(t):
    try:
        m = (await call("GET", "/suggest", params={"q": t}))["match"]
        if m:
            return m
    except Exception as e:
        print("server suggest fail", repr(e))
    try:
        r = await asyncio.wait_for(g.aio.models.generate_content(model="gemma-4-31b-it", contents=P % t.replace('"', ""), config=cfg), 20)
        raw = (r.text or "").strip().splitlines()[-1].lower()
        if "?" in raw:
            return None
        s = re.sub(r"[^a-z ]", "", raw).strip()
        return s if s and len(s.split()) <= 3 else None
    except Exception as e:
        print("gemma suggest fail", repr(e))
        return None

class Retry(discord.ui.Modal, title="Retype the item"):
    name = discord.ui.TextInput(label="What did you mean?", max_length=50)

    def __init__(self, view):
        super().__init__()
        self.v = view

    async def on_submit(self, b):
        self.v.choice = "no"
        self.v.text = self.name.value.lower().strip()
        await b.response.edit_message(content="🔍 Checking again...", embed=None, view=None)
        self.v.stop()

class Ask(discord.ui.View):
    def __init__(self, user, unknown=False):
        super().__init__(timeout=90)
        self.user, self.choice, self.text = user, None, None
        if unknown:
            self.remove_item(self.yes)
            self.keep.label = "Yes, add it"
            self.keep.style = discord.ButtonStyle.success
            self.no.label = "No, retype"

    async def interaction_check(self, b):
        return b.user.id == self.user.id

    @discord.ui.button(label="Yes", style=discord.ButtonStyle.success)
    async def yes(self, b, btn):
        self.choice = "yes"
        await b.response.edit_message(view=None)
        self.stop()

    @discord.ui.button(label="No", style=discord.ButtonStyle.danger)
    async def no(self, b, btn):
        await b.response.send_modal(Retry(self))

    @discord.ui.button(label="Use as typed", style=discord.ButtonStyle.secondary)
    async def keep(self, b, btn):
        self.choice = "keep"
        await b.response.edit_message(view=None)
        self.stop()

async def resolve(i, text):
    text = text.lower().strip()
    while True:
        s = await suggest(text)
        if s == text:
            return text
        v = Ask(i.user, unknown=s is None)
        e = discord.Embed(title="🧐 Don't recognize that" if s is None else "🤔 Did you mean this?", color=0xFFB84D if s is None else 0x7C9CFF)
        e.description = f"Do you really mean **{text}**?" if s is None else f"You typed **{text}**.\nDid you mean **{s}**?"
        m = await i.followup.send(embed=e, view=v, wait=True)
        await v.wait()
        if v.choice == "yes":
            return s
        if v.choice == "keep":
            return text
        if v.choice == "no":
            text = v.text
            continue
        await m.edit(content="⏱️ Timed out, nothing added.", embed=None, view=None)
        return None

@tree.command(name="help", description="Show commands")
async def help_(i: discord.Interaction):
    await i.response.send_message("**Commands**\n`/add item quantity` add something to buy\n`/remove item quantity` remove your item (0 = all)\n`/done item quantity` mark what you bought (`/done all` checks everything)\n`/show` show what's left to buy\n`/history` download the full history as a .txt file")

@tree.command(name="add", description="Add an item to buy")
@app_commands.describe(item="Item name", quantity="How many")
async def add(i: discord.Interaction, item: str, quantity: app_commands.Range[int, 1, 1000] = 1):
    await i.response.defer()
    final = await resolve(i, item)
    if not final:
        return
    r = await call("POST", "/add", {"user": i.user.display_name, "uid": str(i.user.id), "item": final, "qty": quantity})
    await i.followup.send(f"✅ **{i.user.display_name}** added {quantity}x **{r['item']}** (total: {r['total']})")

@tree.command(name="remove", description="Remove one of your items")
@app_commands.describe(item="Item name", quantity="How many to remove (0 = all)")
async def remove(i: discord.Interaction, item: str, quantity: app_commands.Range[int, 0, 1000] = 0):
    r = await call("POST", "/remove", {"user": i.user.display_name, "item": item, "qty": quantity})
    msg = f"🗑️ Removed {r['removed']}x **{r['item']}**" if r["removed"] else f"❌ You have no **{r['item']}** on the list"
    await i.response.send_message(msg)

@tree.command(name="done", description="Mark what you bought")
@app_commands.describe(item="Pick an item from the list, or 'all'", quantity="How many you bought (0 = everything requested)")
async def done(i: discord.Interaction, item: str, quantity: app_commands.Range[int, 0, 1000] = 0):
    await i.response.defer()
    r = await call("POST", "/done", {"user": i.user.display_name, "uid": str(i.user.id), "item": item, "qty": quantity})
    if not r["bought"]:
        return await i.followup.send(f"❌ **{r['item']}** isn't on the list")
    what = "everything on the list" if r["item"] == "all" else f"{r['bought']}x **{r['item']}**"
    await i.followup.send(f"🎉 **{i.user.display_name}** bought {what}" + (f" ({r['bought']} units)" if r["item"] == "all" else ""))

@done.autocomplete("item")
async def done_ac(i: discord.Interaction, current: str):
    try:
        rows = await call("GET", "/list")
    except Exception:
        return []
    tot = {}
    for r in rows:
        if not r["done"]:
            tot[r["item"]] = tot.get(r["item"], 0) + r["qty"]
    out = [app_commands.Choice(name=f"{k} ({v} to buy)", value=k) for k, v in tot.items() if current.lower() in k]
    if tot and "all".startswith(current.lower()):
        out.insert(0, app_commands.Choice(name=f"all ({sum(tot.values())} units)", value="all"))
    return out[:25]

@tree.command(name="show", description="Show what's left to buy")
async def show(i: discord.Interaction):
    rows = await call("GET", "/list")
    p = [f"• {r['qty']}x **{r['item']}** — {r['user']}" for r in rows if not r["done"]]
    if not p:
        return await i.response.send_message("Nothing left to buy. Use `/add` to add something.")
    await i.response.send_message(("**🛒 To buy**\n" + "\n".join(p))[:1900])

@tree.command(name="history", description="Download the full history as a .txt file")
async def history(i: discord.Interaction):
    await i.response.defer(ephemeral=True)
    rows = await call("GET", "/api/history")
    if not rows:
        return await i.followup.send("No history yet.", ephemeral=True)
    ts = lambda t: datetime.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S")
    out = ["GROUPCART HISTORY", "Exported " + ts(datetime.datetime.now().timestamp()), "=" * 50, ""]
    for r in reversed(rows):
        k, a, u, it, q = r["kind"], r["actor"], r["user"], r["item"], r["qty"]
        if k == "add":
            txt = f"{a} placed {q}x {it}" + (f" for {u}" if u.lower() != a.lower() else "")
        elif k == "buy":
            txt = f"{a} bought {q}x {it}" + (f" for {u}" if u.lower() != a.lower() else " for themselves")
            if r.get("placed_ts"):
                txt += f" (ordered {ts(r['placed_ts'])} by {r.get('placed_by') or u})"
        elif k == "remove":
            txt = f"{a} removed {q}x {it}"
        else:
            txt = f"{a} cleared {q} bought units from the list"
        out.append(f"[{ts(r['ts'])}] {k.upper():<6} {txt}")
    f = discord.File(io.BytesIO("\n".join(out).encode("utf-8")), filename="groupcart-history.txt")
    await i.followup.send(f"📜 Full history ({len(rows)} events)", file=f, ephemeral=True)

@tasks.loop(seconds=3)
async def dm_pump():
    try:
        rows = await call("GET", "/dms/pending")
    except Exception:
        return
    ids = []
    for r in rows:
        ids.append(r["id"])
        try:
            u = await client.fetch_user(int(r["uid"]))
            await u.send(r["text"])
        except Exception as e:
            print("dm fail", r["uid"], repr(e))
    if ids:
        try:
            await call("POST", "/dms/ack", {"ids": ids})
        except Exception as e:
            print("ack fail", repr(e))

@tasks.loop(seconds=60)
async def roster_loop():
    ms = {m.id: m.display_name for gd in client.guilds for m in gd.members if not m.bot}
    if ms:
        try:
            await call("POST", "/roster", {"members": [{"uid": str(k), "name": v} for k, v in ms.items()]})
        except Exception as e:
            print("roster fail", repr(e))

@client.event
async def on_ready():
    global http
    if http is None:
        http = aiohttp.ClientSession()
    for gd in client.guilds:
        tree.copy_global_to(guild=gd)
        await tree.sync(guild=gd)
    if not dm_pump.is_running():
        dm_pump.start()
    if not roster_loop.is_running():
        roster_loop.start()
    print("ready", client.user)

client.run("MTU1NjE5Njg0MTQzODA2MDYzNA.GkfI3j.2x3N22OCEq8nXdDFrWZOducaYttLuBLkEGYhf0")