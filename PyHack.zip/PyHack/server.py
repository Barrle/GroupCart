import os, time, sqlite3, difflib
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = os.path.dirname(os.path.abspath(__file__))
known = ["notebook", "pen", "pencil", "eraser", "ruler", "marker", "highlighter", "stapler", "folder", "sharpener", "glue", "scissors", "tape", "paper", "calculator", "bag"]

def db():
    c = sqlite3.connect(os.path.join(BASE, "data.db"))
    c.row_factory = sqlite3.Row
    return c

with db() as c:
    c.execute("CREATE TABLE IF NOT EXISTS rows (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, item TEXT, qty INTEGER, done INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS members (name TEXT PRIMARY KEY)")
    c.execute("CREATE TABLE IF NOT EXISTS notifs (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, msg TEXT, read INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS dms (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, text TEXT, sent INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS roster (uid TEXT PRIMARY KEY, name TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS hist (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, actor TEXT, user TEXT, item TEXT, qty INTEGER)")
    cols = [r[1] for r in c.execute("PRAGMA table_info(rows)")]
    for col in ("uid", "buyer", "added_by"):
        if col not in cols:
            c.execute(f"ALTER TABLE rows ADD COLUMN {col} TEXT")
    if "cleared" not in cols:
        c.execute("ALTER TABLE rows ADD COLUMN cleared INTEGER DEFAULT 0")
    if "pts" not in cols:
        c.execute("ALTER TABLE rows ADD COLUMN pts INTEGER")
    hc = [r[1] for r in c.execute("PRAGMA table_info(hist)")]
    if "placed_by" not in hc:
        c.execute("ALTER TABLE hist ADD COLUMN placed_by TEXT")
    if "placed_ts" not in hc:
        c.execute("ALTER TABLE hist ADD COLUMN placed_ts INTEGER")
    if "uid" not in [r[1] for r in c.execute("PRAGMA table_info(members)")]:
        c.execute("ALTER TABLE members ADD COLUMN uid TEXT")
    c.execute("UPDATE members SET uid=(SELECT r.uid FROM rows r WHERE lower(r.user)=lower(members.name) AND r.uid IS NOT NULL AND r.uid!='' ORDER BY r.id DESC LIMIT 1) WHERE uid IS NULL OR uid=''")

def names(c):
    out = {}
    for n in [r[0] for r in c.execute("SELECT name FROM roster")] + [r[0] for r in c.execute("SELECT name FROM members")] + [r[0] for r in c.execute("SELECT DISTINCT user FROM rows")]:
        if n:
            out.setdefault(n.lower(), n)
    return out

def canon(c, n):
    n = n.strip()
    return names(c).get(n.lower(), n)

def pool():
    with db() as c:
        return list(dict.fromkeys(known + [r[0] for r in c.execute("SELECT DISTINCT item FROM rows")]))

def fix(s):
    s = s.lower().strip()
    m = difflib.get_close_matches(s, pool(), 1, 0.75)
    return m[0] if m else s

def notify(c, user, msg):
    c.execute("INSERT INTO notifs (user, msg) VALUES (?, ?)", (user, msg))

def log(c, kind, actor, user, item, qty, pby=None, pts=None):
    c.execute("INSERT INTO hist (ts, kind, actor, user, item, qty, placed_by, placed_ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (int(time.time()), kind, actor, user, item, qty, pby, pts))

def in_roster(c, n):
    if not c.execute("SELECT 1 FROM roster LIMIT 1").fetchone():
        return True
    return bool(c.execute("SELECT 1 FROM roster WHERE lower(name)=lower(?)", (n.strip(),)).fetchone())

@app.get("/suggest")
def suggest(q: str):
    q = q.lower().strip()
    p = pool()
    if q in p:
        return {"match": q}
    m = difflib.get_close_matches(q, p, 1, 0.6)
    return {"match": m[0] if m else None}

@app.post("/login")
def login(d: dict):
    with db() as c:
        n = canon(c, d["name"])
        if not d.get("uid") and not in_roster(c, n):
            return {"error": "That name isn't in the Discord server."}
        c.execute("INSERT OR IGNORE INTO members (name) VALUES (?)", (n,))
        if d.get("uid"):
            c.execute("UPDATE members SET uid=? WHERE name=?", (str(d["uid"]), n))
    return {"name": n}

@app.get("/members")
def members():
    with db() as c:
        r = {x[0] for x in c.execute("SELECT name FROM roster")}
        return sorted(r or names(c).values(), key=str.lower)

@app.post("/add")
def add(d: dict):
    k = d["item"].lower().strip()
    q = int(d["qty"])
    with db() as c:
        user = canon(c, d["user"])
        by = canon(c, d.get("by") or user)
        if user.lower() != by.lower():
            return {"error": "You can only add orders for yourself."}
        if not d.get("uid") and not (in_roster(c, user) and in_roster(c, by)):
            return {"error": "Pick someone from the Discord server."}
        c.execute("INSERT OR IGNORE INTO members (name) VALUES (?)", (user,))
        c.execute("INSERT OR IGNORE INTO members (name) VALUES (?)", (by,))
        c.execute("INSERT INTO rows (user, item, qty, uid, added_by, pts) VALUES (?, ?, ?, ?, ?, ?)", (user, k, q, str(d.get("uid") or ""), by, int(time.time())))
        log(c, "add", by, user, k, q)
        if by.lower() != user.lower():
            notify(c, user, f"📝 {by} added {q}x {k} to the list for you")
        t = c.execute("SELECT SUM(qty) FROM rows WHERE item=? AND done=0", (k,)).fetchone()[0]
    return {"item": k, "total": t}

@app.post("/remove")
def remove(d: dict):
    k = fix(d["item"])
    left = d.get("qty") or None
    n = 0
    with db() as c:
        for r in c.execute("SELECT id, qty FROM rows WHERE lower(user)=lower(?) AND item=? AND done=0 ORDER BY id", (d["user"], k)).fetchall():
            t = r["qty"] if left is None else min(r["qty"], left)
            n += t
            if t == r["qty"]:
                c.execute("DELETE FROM rows WHERE id=?", (r["id"],))
            else:
                c.execute("UPDATE rows SET qty=qty-? WHERE id=?", (t, r["id"]))
            if left is not None:
                left -= t
                if left == 0:
                    break
        if n:
            log(c, "remove", d["user"], d["user"], k, n)
    return {"item": k, "removed": n}

@app.post("/done")
def done(d: dict):
    s = d["item"].lower().strip()
    want = int(d.get("qty") or 0)
    shares, bought = {}, 0
    with db() as c:
        buyer = canon(c, d["user"])
        c.execute("INSERT OR IGNORE INTO members (name) VALUES (?)", (buyer,))
        if s == "all":
            k, want = "all", 0
            rows = c.execute("SELECT * FROM rows WHERE done=0 ORDER BY id").fetchall()
        else:
            k = fix(s)
            rows = c.execute("SELECT * FROM rows WHERE item=? AND done=0 ORDER BY id", (k,)).fetchall()
        left = want or None
        for r in rows:
            t = r["qty"] if left is None else min(r["qty"], left)
            if t <= 0:
                break
            if t == r["qty"]:
                c.execute("UPDATE rows SET done=1, buyer=? WHERE id=?", (buyer, r["id"]))
            else:
                c.execute("UPDATE rows SET qty=qty-? WHERE id=?", (t, r["id"]))
                c.execute("INSERT INTO rows (user, item, qty, done, uid, buyer, added_by, pts) VALUES (?, ?, ?, 1, ?, ?, ?, ?)", (r["user"], r["item"], t, r["uid"], buyer, r["added_by"], r["pts"]))
            key = (r["uid"] or "", r["user"], r["item"])
            shares[key] = shares.get(key, 0) + t
            bought += t
            log(c, "buy", buyer, r["user"], r["item"], t, r["added_by"], r["pts"])
            if left is not None:
                left -= t
                if left == 0:
                    break
        by_user = {}
        for (_, user, item), q in shares.items():
            if user.lower() != buyer.lower():
                notify(c, user, f"📦 {buyer} bought {q}x {item} from your order")
                by_user.setdefault(user, []).append((item, q))
        for user, lines in by_user.items():
            m = c.execute("SELECT uid FROM members WHERE lower(name)=lower(?)", (user,)).fetchone()
            if m and m["uid"]:
                text = f"📦 **{buyer}** bought items from your request:\n" + "\n".join(f"• {q}x **{it}**" for it, q in lines)
                c.execute("INSERT INTO dms (uid, text) VALUES (?, ?)", (m["uid"], text))
    return {"item": k, "bought": bought, "shares": [{"uid": a, "user": b, "item": it, "qty": q} for (a, b, it), q in shares.items()]}

@app.get("/dms/pending")
def dms_pending():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT id, uid, text FROM dms WHERE sent=0 ORDER BY id LIMIT 20")]

@app.post("/dms/ack")
def dms_ack(d: dict):
    with db() as c:
        c.executemany("UPDATE dms SET sent=1 WHERE id=?", [(int(i),) for i in d["ids"]])
    return {"ok": True}

@app.get("/notifs")
def notifs(user: str):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM notifs WHERE lower(user)=lower(?) ORDER BY id DESC LIMIT 30", (user,))]

@app.post("/notifs/read")
def read(d: dict):
    with db() as c:
        c.execute("UPDATE notifs SET read=1 WHERE lower(user)=lower(?)", (d["user"],))
    return {"ok": True}

@app.get("/list")
def lst():
    with db() as c:
        return [{**dict(r), "done": bool(r["done"])} for r in c.execute("SELECT * FROM rows ORDER BY id")]

@app.get("/orders")
def orders():
    tot, users, dn = {}, {}, {}
    with db() as c:
        for r in c.execute("SELECT * FROM rows"):
            if r["done"]:
                dn[r["item"]] = dn.get(r["item"], 0) + r["qty"]
                continue
            tot[r["item"]] = tot.get(r["item"], 0) + r["qty"]
            u = users.setdefault(r["user"], {})
            u[r["item"]] = u.get(r["item"], 0) + r["qty"]
    return {"totals": tot, "users": users, "done": dn}

@app.post("/roster")
def roster(d: dict):
    ms = d.get("members") or []
    if not ms:
        return {"ok": False}
    with db() as c:
        c.execute("DELETE FROM roster")
        c.executemany("INSERT OR REPLACE INTO roster (uid, name) VALUES (?, ?)", [(str(m["uid"]), m["name"]) for m in ms])
        for m in ms:
            c.execute("UPDATE members SET uid=? WHERE lower(name)=lower(?) AND (uid IS NULL OR uid='')", (str(m["uid"]), m["name"]))
    return {"ok": True}

@app.post("/clear")
def clear(d: dict):
    with db() as c:
        n = c.execute("SELECT COALESCE(SUM(qty), 0) FROM rows WHERE done=1 AND cleared=0").fetchone()[0]
        c.execute("UPDATE rows SET cleared=1 WHERE done=1 AND cleared=0")
        if n:
            log(c, "clear", canon(c, d["user"]), "", "", n)
    return {"cleared": n}

@app.get("/api/history")
def history():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM hist ORDER BY id DESC LIMIT 2000")]

@app.get("/history")
def history_page():
    return FileResponse(os.path.join(BASE, "history.html"), headers={"Cache-Control": "no-store"})

@app.get("/")
def home():
    return FileResponse(os.path.join(BASE, "index.html"), headers={"Cache-Control": "no-store"})